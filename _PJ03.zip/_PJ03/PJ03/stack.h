// Irakli Eradze  ASU ID (emplid): 1222868231

#ifndef STACK_H
#define STACK_H

#include "data_structures.h"

// Stack operations
void Push(pSTACK stack, int item);
int Pop(pSTACK stack);
int IsEmpty(pSTACK stack);

#endif