// Irakli Eradze  ASU ID (emplid): 1222868231

#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data_structures.h"
#include "util.h"

int main(int argc, char **argv);

#endif // MAIN_H
