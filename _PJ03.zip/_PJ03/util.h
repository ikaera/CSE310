// Irakli Eradze  ASU ID (emplid): 1222868231

#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function prototype for parsing instructions
int nextInstruction(char *Word, int *index, double *newKey);

#endif // UTIL_H
