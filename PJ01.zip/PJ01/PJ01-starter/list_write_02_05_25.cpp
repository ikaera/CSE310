// Irakli Eradze  ASU ID (emplid): 1222868231

#include "list_read.h"
#include "list_write.h"
#include <stdio.h>
#include <stdlib.h>

void listRelease(LIST *pLIST){
    //fprintf(stderr, "You need to write the function listRelease\n");
    // Check for NULL pointer	
    if(pLIST == NULL) return;

    NODE *current = pLIST->head;

    while (current != NULL) { 
	    NODE *next = current->next;
	    free(current);
	    current = next;    
    }
    // Ensure all list properties are reset to NULL or/and 0
    pLIST->head = NULL;
    pLIST->tail = NULL;
    pLIST->length = 0;
}


NODE * listInsert(LIST *pLIST, double key){
   // NODE *pNODE;
   // pNODE = NULL;
    //Check for NULL before accessing its member
    if (pLIST == NULL) return NULL; 
				   
    NODE *newNode = new NODE();
    newNode->key = key;

    newNode->next = nullptr;
	
    if (pLIST->length == 0) {
	    pLIST->head = newNode;
	    pLIST->tail = newNode;
    } else {
	    newNode->next = pLIST->head;
	    pLIST->head = newNode;
    }
    // increase the length of the list
    pLIST ->length++;

   // fprintf(stdout,"Node with key %.6f inserted\n", key);

    return newNode;
   
    // assign the key value
	
    // fprintf(stderr, "You need to write the function listInsert\n");
    // return pNODE;
}


NODE * listAppend(LIST *pLIST, double key){
    //NODE *pNODE;
   // pNODE = NULL;
   //
   NODE *newNode = new NODE();
   newNode->key = key;
   newNode->next = nullptr;

   if (pLIST->length == 0) {
	   pLIST->head = newNode;
	   pLIST->tail = newNode;   
   } else {
	   pLIST->tail->next = newNode;
	   pLIST->tail = newNode;   
   }
   pLIST->length++;


   // fprintf(stdout, "Node with %.6f appended\n", key);
    return newNode;
}


NODE * listDelete(LIST *pLIST, double key){
    if (pLIST == NULL || pLIST->head == NULL) {
        return NULL; // Empty List
    }
    // Use listSearch to locate the node to delete
    NODE* targetNode = listSearch(pLIST, key);
    if (!targetNode) {
        fprintf(stdout, "Warning in listDelete: Key %.6f not in list\n", key);
        return NULL;
    }
    NODE* temp = NULL;
    // case 1: deleteFirst
    if (targetNode == pLIST->head) {
        temp = pLIST->head;
        
        // if (pLIST->length == 0) return;          
        if (pLIST->length == 1) {
                pLIST->head = NULL;
                pLIST->tail = NULL;
            } else {
                pLIST->head = pLIST->head->next;
            }
            //delete temp;
            pLIST->length--;
            return temp;
    }
    // case 2: deleteLast
    if (targetNode == pLIST->tail) {
        // if (pLIST->length == 0) return;
            NODE* temp = pLIST->head;
            if (pLIST->length == 1) {
                pLIST->head = nullptr;
                pLIST->tail = nullptr;
            } else {
                NODE* pre = pLIST->head;
                while (temp->next) {
                    pre = temp;
                    temp = temp->next;
                }
                pLIST->tail = pre;
                pLIST->tail->next = NULL;
            }
            //delete temp;
            pLIST->length--;
            return targetNode;
    }
    // case 3: 
    NODE* prev = pLIST->head;
    temp = prev->next;
        // traverse pLIST starting the second node
        while(temp) {
            if(temp == targetNode) {
                prev->next = temp->next;
                // delete temp;
                pLIST->length--;
                return targetNode;
            }
            prev = temp;
            temp = temp->next;
        }
}                
    // Special case: deleting the head node
    
    //return temp;    

    //fprintf(stdout, "Node with %.6f deleted\n", key);
    // fprintf(stdout, "Warning in listDelete: Key %.6f not in list\n", key);
    // if key not dound
    //return NULL;
