#ifndef _util_h
#define _util_h 1

int  nextInstruction(char *Word, double *Key);

#endif
