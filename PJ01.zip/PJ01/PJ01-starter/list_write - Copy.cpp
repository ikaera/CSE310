// Irakli Eradze  ASU ID (emplid): 1222868231
#include "list_read.h"
#include "list_write.h"
#include <stdio.h>
#include <stdlib.h>

void listRelease(LIST *pLIST){
    fprintf(stderr, "You need to write the function listRelease\n");

    NODE *current = pLIST->head;
    while (current != nullptr) {
        NODE *next = current->next;
        delete current; // Free memory for the current node
        current = next;
    }
    pLIST->head = nullptr; // Reset the head and tail pointers
    pLIST->tail = nullptr;
    pLIST->length = 0;     // Reset the length of the list

}


NODE * listInsert(LIST *pLIST, double key){
    NODE *pNODE;
    pNODE = NULL;
    fprintf(stderr, "You need to write the function listInsert\n");
    // return pNODE;
    NODE *newNode = new NODE(); // Allocate memory for the new node
    newNode->key = key;         // Assign the key value
    //
    
    //       // Set the new node as the head

    // If the list was empty, set the head and the tail to the new node
    if (pLIST->tail == nullptr) {
        pLIST->head = newNode;
        pLIST->tail = newNode;
    } else {
        newNode->next = pLIST->head;
        pLIST->head = newNode;
    }

    pLIST->length++;            // Increase the length of the list
    return newNode;
}


NODE * listAppend(LIST *pLIST, double key){
    NODE *pNODE;
    pNODE = NULL;
    fprintf(stderr, "You need to write the function listAppend\n");
    // return pNODE;
    NODE *newNode = new NODE(); // Allocate memory for the new node
    newNode->key = key;         // Assign the key value
    newNode->next = nullptr;

    if (pLIST->tail != nullptr) {
        pLIST->tail->next = newNode; // Update the next pointer of the old tail
    } else {
        pLIST->head = newNode;      // If the list was empty, set the head to the new node
    }

    pLIST->tail = newNode;          // Set the new node as the tail
    pLIST->length++;                // Increase the length of the list
    return newNode;
}


NODE * listDelete(LIST *pLIST, double key){
    NODE *pNODE;
    pNODE = NULL;
    fprintf(stderr, "You need to write the function listDelete\n");
    // return pNODE;

    if (pLIST == NULL || pLIST->head == NULL) {
        return NULL; // List is empty or invalid
    }

    NODE *current = pLIST->head;
    NODE *previous = NULL;

    // Traverse the list to find the node with the matching key
    while (current != NULL) {
        if (current->key == key) {
            // Node with the matching key found
            if (previous == NULL) {
                // Deleting the head node
                pLIST->head = current->next;
                if (pLIST->head == NULL) {
                    // List is now empty
                    pLIST->tail = NULL;
                }
            } else {
                // Deleting a middle or tail node
                previous->next = current->next;
                if (current == pLIST->tail) {
                    // Update tail if the deleted node was the tail
                    pLIST->tail = previous;
                }
            }

            pLIST->length--;
            free(current);
            return pLIST->head;
        }

        // Move to the next node
        previous = current;
        current = current->next;
    }

    // Key not found
    fprintf(stdout, "Warning in listDelete: Key %.6f not in list\n", key);

    return NULL;
}

