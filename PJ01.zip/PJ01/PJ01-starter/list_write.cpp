// Irakli Eradze  ASU ID (emplid): 1222868231

#include "list_read.h"
#include "list_write.h"
#include <stdio.h>
#include <stdlib.h>

void listRelease(LIST *pLIST){
    //fprintf(stderr, "You need to write the function listRelease\n");
    // Check for NULL pointer	
    if(pLIST == NULL) return;

    NODE *current = pLIST->head;

    while (current != NULL) { 
	    NODE *next = current->next;
	    free(current);
	    current = next;    
    }
    // Ensure all list properties are reset to NULL or/and 0
    pLIST->head = NULL;
    pLIST->tail = NULL;
    pLIST->length = 0;
}


NODE * listInsert(LIST *pLIST, double key){
   // NODE *pNODE;
   // pNODE = NULL;
    //Check for NULL before accessing its member
    if (pLIST == NULL) return NULL; 
				   
    NODE *newNode = (NODE *)malloc(sizeof(NODE));
    newNode->key = key;

    newNode->next = NULL;
	
    if (pLIST->length == 0) {
	    pLIST->head = newNode;
	    pLIST->tail = newNode;
    } else {
	    newNode->next = pLIST->head;
	    pLIST->head = newNode;
    }
    // increase the length of the list
    pLIST ->length++;   

    return newNode;   
    // fprintf(stderr, "You need to write the function listInsert\n");
    // return pNODE;
}

NODE * listAppend(LIST *pLIST, double key){
    //NODE *pNODE;
   // pNODE = NULL;
   //
   NODE *newNode = (NODE *)malloc(sizeof(NODE));
   newNode->key = key;
   newNode->next = NULL;

   if (pLIST->length == 0) {
	   pLIST->head = newNode;
	   pLIST->tail = newNode;   
   } else {
	   pLIST->tail->next = newNode;
	   pLIST->tail = newNode;   
   }
   pLIST->length++;
   // fprintf(stdout, "Node with %.6f appended\n", key);
    return newNode;
}

// For learning purposes used example code by Scott Barrett's Udemy course: C++ Data Structures & Algorithms, 
// https://www.udemy.com/course/data-structures-algorithms-cpp/learn/lecture/42896026?start=1#overview
// https://www.udemy.com/course/data-structures-algorithms-cpp/learn/lecture/42896026#content

NODE * listDelete(LIST *pLIST, double key){
    if (pLIST == NULL || pLIST->head == NULL) {
        return NULL; // Empty List
    }
    // Use listSearch to locate the node that = key
    NODE* targetNode = listSearch(pLIST, key);
    if (!targetNode) {
        fprintf(stdout, "Warning in listDelete: Key %.6f not in list\n", key);
        return NULL;
    }
    NODE* temp = NULL;
    // case 1: deleteFirst
    if (targetNode == pLIST->head) {
        temp = pLIST->head;        
        // if (pLIST->length == 0) return;          
        if (pLIST->length == 1) {
                pLIST->head = NULL;
                pLIST->tail = NULL;
            } else {
                pLIST->head = pLIST->head->next;
            }
            //delete temp;
            pLIST->length--;
            return targetNode;
    }
        
    // case 2: delete node in the middle 
    NODE* prev = pLIST->head;
    temp = prev->next;
        // traverse pLIST starting the second node
        while(temp) {
            if(temp == targetNode) {
                prev->next = temp->next;
                // delete temp;
                pLIST->length--;
                return targetNode;
            }
            prev = temp;
            temp = temp->next;
        }
    
    // case 3: deleteLast
    if (targetNode == pLIST->tail) {
        // if (pLIST->length == 0) return;
        temp = pLIST->head;
        if (pLIST->length == 1) {
            pLIST->head = NULL;
            pLIST->tail = NULL;
        } else {
            NODE* pre = pLIST->head;
            while (temp->next) {
                pre = temp;
                temp = temp->next;
            }
        pLIST->tail = pre;
        pLIST->tail->next = NULL;
        }
            //delete temp;
        pLIST->length--;
        return targetNode;
    }        
}