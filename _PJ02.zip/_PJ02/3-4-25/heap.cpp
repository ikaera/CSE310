// Irakli Eradze  ASU ID (emplid): 1222868231

#include "heap.h"
#include <stdio.h>
#include <stdlib.h>

// Helper function to maintain the heap property at index i
void Heapify(HEAP *heap, ELEMENT **V, int i) {
    int smallest = i;       // Initialize smallest as the root
    int left = 2 * i;       // Left child
    int right = 2 * i + 1;  // Right child

    // If left child is smaller than root
    if (left <= heap->size && V[heap->H[left]]->key < V[heap->H[smallest]]->key) {
        smallest = left;
    }

    // If right child is smaller than the smallest so far
    if (right <= heap->size && V[heap->H[right]]->key < V[heap->H[smallest]]->key) {
        smallest = right;
    }

    // If the smallest is not the root
    if (smallest != i) {
        Swap(V, heap->H[i], heap->H[smallest]); // Swap the elements
        Heapify(heap, V, smallest);             // Recursively heapify the affected subtree
    }
}

// Helper function to swap two elements in the heap
void Swap(ELEMENT **V, int i, int j) {
    int tempPos = V[i]->pos;
    V[i]->pos = V[j]->pos;
    V[j]->pos = tempPos;

    int tempIndex = V[i]->index;
    V[i]->index = V[j]->index;
    V[j]->index = tempIndex;

    double tempKey = V[i]->key;
    V[i]->key = V[j]->key;
    V[j]->key = tempKey;
}

// Function to build the heap using the linear-time BuildHeap algorithm
void BuildHeap(HEAP *heap, ELEMENT **V) {
    for (int i = heap->size / 2; i >= 1; i--) {
        Heapify(heap, V, i);
    }
}

// Function to insert an element into the heap
void Insert(HEAP *heap, ELEMENT **V, int index) {
    if (heap->size >= heap->capacity) {
        fprintf(stderr, "Error: heap is full\n");
        return;
    }

    // Insert the new element at the end of the heap
    heap->size++;
    heap->H[heap->size] = index;
    V[index]->pos = heap->size;

    // Restore the heap property
    int i = heap->size;
    while (i > 1 && V[heap->H[i / 2]]->key > V[heap->H[i]]->key) {
        Swap(V, heap->H[i / 2], heap->H[i]);
        i = i / 2;
    }
}

// Function to extract the minimum element from the heap
void ExtractMin(HEAP *heap, ELEMENT **V) {
    if (heap->size == 0) {
        fprintf(stderr, "Error: heap is empty\n");
        return;
    }

    // The minimum element is at the root (H[1])
    int minIndex = heap->H[1];
    V[minIndex]->pos = 0; // Mark the element as not in the heap

    // Move the last element to the root
    heap->H[1] = heap->H[heap->size];
    V[heap->H[1]]->pos = 1;
    heap->size--;

    // Restore the heap property
    Heapify(heap, V, 1);

    fprintf(stdout, "Element V[%d] extracted from the heap\n", minIndex);
}

// Function to decrease the key of an element in the heap
void DecreaseKey(HEAP *heap, ELEMENT **V, int index, double newKey) {
    if (newKey >= V[index]->key) {
        fprintf(stderr, "Error: new key is not smaller than the current key\n");
        return;
    }

    // Update the key
    V[index]->key = newKey;

    // Restore the heap property
    int i = V[index]->pos;
    while (i > 1 && V[heap->H[i / 2]]->key > V[heap->H[i]]->key) {
        Swap(V, heap->H[i / 2], heap->H[i]);
        i = i / 2;
    }
}
