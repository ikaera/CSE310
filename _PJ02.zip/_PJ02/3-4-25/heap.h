// Irakli Eradze  ASU ID (emplid): 1222868231

#ifndef HEAP_H
#define HEAP_H

#include "data_structures.h"

// Function prototypes for heap operations
void BuildHeap(HEAP *heap, ELEMENT **V);
void Insert(HEAP *heap, ELEMENT **V, int index);
void ExtractMin(HEAP *heap, ELEMENT **V);
void DecreaseKey(HEAP *heap, ELEMENT **V, int index, double newKey);

// Helper functions
void Heapify(HEAP *heap, ELEMENT **V, int i);
void Swap(ELEMENT **V, int i, int j);

#endif // HEAP_H
