#include <stdio.h>
#include <stdbool.h>

// Structure to represent a date
struct Date {
    int day;
    int month;
    int year;
};

// Function to check if a year is a leap year
bool isLeapYear(int year) {
    return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
}

// Function to calculate the total number of days since 0000-00-00
long int totalDays(struct Date date) {
    // Array to store the number of days in each month
    int daysInMonth[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    // Adjust February days for leap years
    if (isLeapYear(date.year)) {
        daysInMonth[2] = 29;
    }

    // Calculate total days
    long int days = date.day;

    // Add days from previous months in the current year
    for (int m = 1; m < date.month; m++) {
        days += daysInMonth[m];
    }

    // Add days from previous years
    days += 365 * date.year; // Add non-leap years
    days += date.year / 4 - date.year / 100 + date.year / 400; // Add leap years

    return days;
}

// Function to calculate the difference in days between two dates
long int daysBetweenDates(struct Date date1, struct Date date2) {
    long int days1 = totalDays(date1);
    long int days2 = totalDays(date2);

    return days2 - days1;
}

int main() {
    struct Date date1, date2;

    // Input first date
    printf("Enter first date (DD MM YYYY): ");
    scanf("%d %d %d", &date1.day, &date1.month, &date1.year);

    // Input second date
    printf("Enter second date (DD MM YYYY): ");
    scanf("%d %d %d", &date2.day, &date2.month, &date2.year);

    // Calculate the difference in days
    long int difference = daysBetweenDates(date1, date2);

    // Output the result
    printf("Number of days between the two dates: %ld\n", difference);

    return 0;
}