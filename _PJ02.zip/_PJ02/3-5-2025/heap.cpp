// Irakli Eradze  ASU ID (emplid): 1222868231

#include "heap.h"
#include <stdio.h>
#include <stdlib.h>

// Function to maintain the heap property at index i
void Heapify(HEAP *heap, ELEMENT **V, int i) {
    int l = 2 * i;       // Left child
    int r = 2 * i + 1;   // Right child
    int smallest = i;    // Initialize smallest as the root

    // If left child is smaller than root
    if (l <= heap->size && V[heap->H[l]]->key < V[heap->H[smallest]]->key) {
        smallest = l;
    }

    // If right child is smaller than the smallest so far
    if (r <= heap->size && V[heap->H[r]]->key < V[heap->H[smallest]]->key) {
        smallest = r;
    }

    // If the smallest is not the root
    if (smallest != i) {
        // Swap the elements
        int temp = heap->H[i];
        heap->H[i] = heap->H[smallest];
        heap->H[smallest] = temp;

        // Update the positions in the ELEMENT array
        V[heap->H[i]]->pos = i;
        V[heap->H[smallest]]->pos = smallest;

        // Recursively heapify the affected subtree
        Heapify(heap, V, smallest);
    }
}

// Function to build the heap using the linear-time BuildHeap algorithm
void BuildHeap(HEAP *heap, ELEMENT **V) {
    // Set the size of the heap
    heap->size = heap->capacity;

    // Initialize the heap array
    for (int i = 1; i <= heap->size; i++) {
        heap->H[i] = i;
        V[i]->pos = i;
    }

    // Build the heap
    for (int i = heap->size / 2; i >= 1; i--) {
        Heapify(heap, V, i);
    }
}

// Function to extract the minimum element from the heap
void ExtractMin(HEAP *heap, ELEMENT **V) {
    // Check if the heap is empty
    if (heap->size < 1) {
        fprintf(stderr, "Error: heap is empty\n");
        return;
    }

    // The minimum element is at the root
    int minIndex = heap->H[1];
    V[minIndex]->pos = 0; // Mark the element as not in the heap

    // Move the last element to the root
    heap->H[1] = heap->H[heap->size];
    V[heap->H[1]]->pos = 1;
    heap->size--; // Decrease the size of the heap

    // Restore the heap property
    Heapify(heap, V, 1);

    // Print success message
    fprintf(stdout, "Element V[%d] extracted from the heap\n", minIndex);
}

// Function to decrease the key of an element in the heap
void DecreaseKey(HEAP *heap, ELEMENT **V, int index, double newKey, int n) {
    // Check if the new key is larger than the current key
    if (newKey >= V[index]->key) {
        fprintf(stderr, "Error: new key is not smaller than the current key\n");
        return;
    }

    // Update the key
    V[index]->key = newKey;

    // Restore the heap property by moving the element up
    int i = V[index]->pos;
    while (i > 1 && V[heap->H[i / 2]]->key > V[heap->H[i]]->key) {
        // Swap the element with its parent
        int temp = heap->H[i];
        heap->H[i] = heap->H[i / 2];
        heap->H[i / 2] = temp;

        // Update the positions in the ELEMENT array
        V[heap->H[i]]->pos = i;
        V[heap->H[i / 2]]->pos = i / 2;

        // Move up to the parent
        i = i / 2;
    }
}

// Function to insert an element into the heap
void Insertion(HEAP *heap, ELEMENT **V, int index, int n) {
    // Check if the index is out of bounds
   /* if (index < 1 || index > n) {
        fprintf(stderr, "Error: index out of bound\n");
        return;
    }
*/
    // Check if the element is already in the heap
 

    // Insert the element into the heap
    heap->size++; // Increase the size of the heap
    heap->H[heap->size] = index; // Add the element to the end of the heap array
    V[index]->pos = heap->size; // Update the position of the element in the heap

    // Decrease the key to the actual value (simulate insertion with ∞)
    DecreaseKey(heap, V, index, V[index]->key, n);

    // Print success message
 //   fprintf(stdout, "Element V[%d] inserted into the heap at position %d\n", index, V[index]->pos);
}
