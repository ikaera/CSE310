#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "util.h"
#include "heap.h"


int main(int argc, char **argv) {
    FILE *fp1, *fp2;
    HEAP *pHeap;
ELEMENT **V;
    ELEMENT *pElement;
    double key;
    int returnV, flag;
    char Word[100];

    // Validate command-line arguments
    if (argc < 4) {
        fprintf(stderr, "Usage: %s <ifile> <ofile> <flag>\n", argv[0]);
        exit(0);
    }
    flag = atoi(argv[3]);
    fp1 = NULL;
    fp2 = NULL;
    pHeap = (HEAP *)calloc(1, sizeof(HEAP));
V = (ELEMENT **)malloc(100 * sizeof(ELEMENT *)); // Example capacity

    if (!pHeap || !V) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        exit(0);
    }
    pHeap->size = 0;
    pHeap->capacity = 100;
for (int i = 0; i < pHeap->capacity; i++) {
    V[i] = (ELEMENT *)malloc(sizeof(ELEMENT));
    V[i]->pos = 0;
}
    pHeap->H = (int *)malloc(pHeap->capacity * sizeof(int));

    // Open the output file
    fp2 = fopen(argv[2], "w");
    if (!fp2) {
        fprintf(stderr, "Error: Cannot open file %s\n", argv[2]);
        exit(0);
    }

    // Process instructions
    while (1) {
        returnV = nextInstruction(Word, &key);
        if (returnV == 0) {
            fprintf(stderr, "Warning: Invalid instruction: %s\n", Word);
            continue;
        }

        if (strcmp(Word, "Stop") == 0) {
            fclose(fp2);
            return 0;
        }
        if (strcmp(Word, "Release") == 0) {
            free(pHeap->H);
for (int i = 0; i < pHeap->capacity; i++) {
    free(V[i]);
}
free(V);
free(pHeap);
            continue;
        }
        if (strcmp(Word, "Read") == 0) {
    pHeap->size = 0;
    fp1 = fopen(argv[1], "r");
    if (!fp1) {
        fprintf(stderr, "Error: Cannot open file %s
", argv[1]);
        exit(0);
    }
    fscanf(fp1, "%d", &pHeap->capacity);
    for (int i = 1; i <= pHeap->capacity; i++) {
        double key;
        fscanf(fp1, "%lf", &key);
        Insert(pHeap, i, key);
    }
    fclose(fp1);
    continue;
} {
            free(pHeap->H);
for (int i = 0; i < pHeap->capacity; i++) {
    free(V[i]);
}
free(V);
free(pHeap);
            fp1 = fopen(argv[1], "r");
            if (!fp1) {
                fprintf(stderr, "Error: Cannot open file %s\n", argv[1]);
                exit(0);
            }
            while (fscanf(fp1, "%lf", &key) == 1) {
                (flag > 0) ? listAppend(List, key) : listInsert(List, key);
            }
            fclose(fp1);
            continue;
        }
        if (strcmp(Word, "Print") == 0) {
            for (int i = 1; i <= pHeap->size; i++) {
    fprintf(stdout, "%d %lf %d
", V[pHeap->H[i]]->index, V[pHeap->H[i]]->key, V[pHeap->H[i]]->pos);
}
            if (abs(flag) == 2) for (int i = 1; i <= pHeap->size; i++) {
    fprintf(fp2, "%d %lf %d
", V[pHeap->H[i]]->index, V[pHeap->H[i]]->key, V[pHeap->H[i]]->pos);
}
            continue;
        }
        if (strcmp(Word, "ExtractMin") == 0) {
    if (pHeap->size > 0) {
        int minIndex = ExtractMin(pHeap);
        fprintf(stdout, "Extracted min element index: %d
", minIndex);
        if (abs(flag) == 2) fprintf(fp2, "Extracted min element index: %d
", minIndex);
    } else {
        fprintf(stderr, "Error: Heap is empty
");
    }
    continue;
} {
            fprintf(stdout, "Max=%lf\n", listMax(List));
            if (abs(flag) == 2) fprintf(fp2, "Max=%lf\n", listMax(List));
            continue;
        }
        if (strcmp(Word, "Min") == 0) {
            fprintf(stdout, "Min=%lf\n", listMin(List));
            if (abs(flag) == 2) fprintf(fp2, "Min=%lf\n", listMin(List));
            continue;
        }
        if (strcmp(Word, "Sum") == 0) {
            fprintf(stdout, "Sum=%lf\n", listSum(List));
            if (abs(flag) == 2) fprintf(fp2, "Sum=%lf\n", listSum(List));
            continue;
        }
        if (strcmp(Word, "Length") == 0) {
            fprintf(stdout, "Length=%d\n", List->length);
            if (abs(flag) == 2) fprintf(fp2, "Length=%d\n", List->length);
            continue;
        }
        if (strcmp(Word, "Write") == 0) {
            for (int i = 1; i <= pHeap->size; i++) {
    fprintf(fp2, "%d %lf %d
", V[pHeap->H[i]]->index, V[pHeap->H[i]]->key, V[pHeap->H[i]]->pos);
}
            continue;
        }
        if (strcmp(Word, "Search") == 0) {
            int found = -1;
for (int i = 1; i <= pHeap->size; i++) {
    if (V[pHeap->H[i]]->key == key) {
        found = i;
        break;
    }
}
            fprintf(stdout, "Query %lf %s in heap
", key, found != -1 ? "FOUND" : "NOT FOUND");
            if (abs(flag) == 2) fprintf(fp2, "Query %lf %s in heap
", key, found != -1 ? "FOUND" : "NOT FOUND");
            continue;
        }
        if (strcmp(Word, "Insert") == 0) {
    Insert(pHeap, (int)key, key);
    fprintf(stdout, "Element with key %lf inserted
", key);
    if (abs(flag) == 2) fprintf(fp2, "Element with key %lf inserted
", key);
    continue;
} {
            Insert(pHeap, (int)key, key);
            fprintf(stdout, "Node with key %lf inserted into heap
", key);
            if (abs(flag) == 2) fprintf(fp2, "Node with key %lf %s\n", key, pNODE ? "inserted" : "not inserted");
            continue;
        }
        if (strcmp(Word, "Append") == 0) {
            Insert(pHeap, (int)key, key);
            fprintf(stdout, "Node with key %lf %s\n", key, pNODE ? "appended" : "not appended");
            if (abs(flag) == 2) fprintf(fp2, "Node with key %lf %s\n", key, pNODE ? "appended" : "not appended");
            continue;
        }
        if (strcmp(Word, "DecreaseKey") == 0) {
    double newKey;
    fscanf(stdin, "%lf", &newKey);
    DecreaseKey(pHeap, (int)key, newKey);
    fprintf(stdout, "Decreased key of element %d to %lf
", (int)key, newKey);
    if (abs(flag) == 2) fprintf(fp2, "Decreased key of element %d to %lf
", (int)key, newKey);
    continue;
} {
            DecreaseKey(pHeap, (int)key, newKey);
            fprintf(stdout, "Node with key %lf %s\n", key, pNODE ? "deleted" : "not deleted");
            if (abs(flag) == 2) fprintf(fp2, "Node with key %lf %s\n", key, pNODE ? "deleted" : "not deleted");
            if (pNODE) free(pNODE);
            continue;
        }
    }
    return 1;
}
