#include "list_read.h"
#include "list_write.h"
#include <stdio.h>
#include <stdlib.h>

void listRelease(LIST *pLIST){
    fprintf(stderr, "You need to write the function listRelease\n");
}


NODE * listInsert(LIST *pLIST, double key){
    NODE *pNODE;
    pNODE = NULL;
    fprintf(stderr, "You need to write the function listInsert\n");
    return pNODE;
}


NODE * listAppend(LIST *pLIST, double key){
    NODE *pNODE;
    pNODE = NULL;
    fprintf(stderr, "You need to write the function listAppend\n");
    return pNODE;
}


NODE * listDelete(LIST *pLIST, double key){
    NODE *pNODE;
    pNODE = NULL;
    fprintf(stderr, "You need to write the function listDelete\n");
    return pNODE;
}

